package com.example.myapplication;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class search extends AppCompatActivity {

    ListView lv;
    SQLiteDatabase myDB = null;
    String TableName = "city";
    String tag = "TAG";
    EditText t1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        t1 = findViewById(R.id.textView);
        lv = findViewById(R.id.lv);


    }

    public void searchdata(View view) {
        try {
            myDB = this.openOrCreateDatabase("mytestdb", Context.MODE_PRIVATE, null);
            Cursor c = myDB.rawQuery("select * from " + TableName +" WHERE cityname='"+t1.getText().toString()+"'", null);
            String Data[] = new String[c.getCount() + 1];
            int i = 1;
            String header1 = c.getColumnName(0);
            String header2 = c.getColumnName(1);
            String header3 = c.getColumnName(2);
            if (c != null) {
                int c1 = c.getColumnIndex("cityname");
                int c2 = c.getColumnIndex("zipcode");
                int c3 = c.getColumnIndex("district");
                Data[0] = header1 + "\t\t" + header2 + "\t\t" + header3;
                c.moveToFirst();
                do {
                    String cn = c.getString(c1);
                    int zc = c.getInt(c2);
                    String dst = c.getString(c3);
                    Data[i] = cn + " " + zc + " " + dst;
                    i++;

                } while (c.moveToNext());
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, Data);
                lv.setAdapter(adapter);
            }
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
        }

    }
}
