package com.example.myapplication;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity{

    EditText cityname,zipcode,district;
    SQLiteDatabase mydb=null;
    String data="";
    String tablenm="city";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cityname=findViewById(R.id.cityname);
        district=findViewById(R.id.district);
        zipcode=findViewById(R.id.zipcode);
    }

    public void createdb(View view) {
        try{
            mydb=this.openOrCreateDatabase("mytestdb", getBaseContext().MODE_PRIVATE,null);
            mydb.execSQL("CREATE TABLE IF NOT EXISTS city (cityname varchar(15),district varchar(10),zipcode varchar(10));");
            Toast.makeText(getApplicationContext(),"Table Created Sucessfully",Toast.LENGTH_LONG).show();
        }
        catch(Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    public void dropdb(View view) {
        try{
            deleteDatabase("mytestdb");
            Toast.makeText(getApplicationContext(),"Database Deleted Sucessfully",Toast.LENGTH_LONG).show();
        }
        catch(Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
        }

    }

    public void insertdata(View view) {
        try{
            mydb=this.openOrCreateDatabase("mytestdb", getBaseContext().MODE_PRIVATE,null);
            String cname=cityname.getText().toString();
            String zcode=zipcode.getText().toString();
            String dis=district.getText().toString();
            mydb.execSQL("INSERT INTO "+tablenm+"(cityname,district,zipcode)"+"VALUES ('"+cname+"',"+"'"+dis+"',"+"'"+zcode+"');");
            Toast.makeText(getApplicationContext(),"Data Inserted sucessfully",Toast.LENGTH_LONG).show();
        }
        catch(Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    public void viewdata(View view) {
        Intent i=new Intent(this,viewdata.class);
        startActivity(i);


    }

    public void searchdata(View view) {
        Intent i=new Intent(this,search.class);
        startActivity(i);

    }

    public void updatedata(View view) {
    }
}
