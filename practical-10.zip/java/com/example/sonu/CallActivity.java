package com.example.sonu;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.CallLog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.security.Permission;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CallActivity extends AppCompatActivity {
 ListView l1;
 ArrayAdapter<String>adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call);
        l1=findViewById(R.id.call_list);
        if(Build.VERSION.SDK_INT>=23)
        {
            if(checkSelfPermission(Manifest.permission.READ_CALL_LOG)!=PackageManager.PERMISSION_GRANTED);
            {
                requestPermissions(new String[]{Manifest.permission.READ_CALL_LOG},5);
            }
        }
    }
    public void onRequestPermissionResult(int requestCode, String[] permission,int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode,permission,grantResults);
        if(requestCode==5){}
    }


    public void getCallLog(View view) {
        int i=0;
        ContentResolver cr=getContentResolver();
        Uri Calluri=Uri.parse("content://call_log/calls");
        Cursor cursor=cr.query(Calluri,null,null,null,null);
        String temp="";
        String data[]=new String[cursor.getCount()];
        if(cursor==null)
        {
            Toast.makeText(getApplicationContext(),"No record",Toast.LENGTH_LONG).show();

        }
        else
        {
            while(cursor.moveToNext())
            {
                String callNumber=cursor.getString(cursor.getColumnIndex(CallLog.Calls.NUMBER));
                String callName=cursor.getString(cursor.getColumnIndex(CallLog.Calls.CACHED_NAME));
                String callDate=cursor.getString(cursor.getColumnIndex(CallLog.Calls.DATE));
                SimpleDateFormat formatter =new SimpleDateFormat("dd-MMM-yyyy hh:mm");
                String dateString=formatter.format(new Date(Long.parseLong(callDate)));
                String CallType=cursor.getString(cursor.getColumnIndex(CallLog.Calls.TYPE));
                String duration=cursor.getString(cursor.getColumnIndex(CallLog.Calls.DURATION));
                String type="";
                switch (Integer.parseInt(CallType))
                {
                    case 1:
                        type="Incoming";
                        break;
                    case 2:
                        type="Outgoing";
                        break;
                    case 3:
                        type="Missed Call";
                        break;
                }
                temp=callName + " " + dateString + "\n" + callNumber + " " + duration + "\n" + "CallType:" +type ;
                data[i]=temp;
                i++;
            }//end of while
            ArrayAdapter<String> adapter=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,data);
            l1.setAdapter(adapter);
        }//end of else
    }//end of method
}
