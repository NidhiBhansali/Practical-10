package com.example.sonu;

import android.app.assist.AssistContent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.AsyncTask;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;
import android.view.View;
import android.os.SystemClock;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.DataTruncation;

public class AsyncThreadActivity extends AppCompatActivity {

    TextView t1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_async_thread);
   t1=findViewById(R.id.textview);


    }

    public void readwebpage(View view){
        LoadWebPageASYNC task=new LoadWebPageASYNC();
        task.execute("http://www.goggle.com");
    }
    private class LoadWebPageASYNC extends AsyncTask<String,String,String>
    {
        InputStream in=null;
        int rescode=-1;
        String webpage="";
        String urlstr="";
        @Override
        protected String doInBackground(String... urls) {
            try {
                URL link = new URL(urls[0]);
                HttpURLConnection httpConn = (HttpURLConnection) link.openConnection();;
                httpConn.connect();
                rescode = httpConn.getResponseCode();
                if (rescode == HttpURLConnection.HTTP_OK) {
                    in = httpConn.getInputStream();
                }
                publishProgress("Connection Establish");
                BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                String data = " ";
                while ((data = reader.readLine()) != null) {
                    webpage += data + "\n";
                    Toast.makeText(getApplicationContext(), "connection establish", Toast.LENGTH_LONG).show();
                }


            } catch (Exception e) {

            }
            return webpage;
        }
        @Override
        protected void onProgressUpdate(String... values) {
         super.onProgressUpdate(values);
         t1.setText("Progress" + (values[0]));

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            t1.setText(s);

        }
    }
  /*  private void updatewebview(String result)
    {
        //t1.setText(webpage);
    }*/

}
